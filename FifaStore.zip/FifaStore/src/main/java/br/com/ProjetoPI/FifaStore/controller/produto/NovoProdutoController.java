package br.com.ProjetoPI.FifaStore.controller.produto;

import br.com.ProjetoPI.FifaStore.dto.RequisicaoNovoProduto;
import br.com.ProjetoPI.FifaStore.repository.ProdutoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import br.com.ProjetoPI.FifaStore.Model.produto.Produto;
@Controller
@RequestMapping("CadastroProduto")
public class NovoProdutoController {

    @Autowired
    private ProdutoRepository NovoprodutoRepository;

    @GetMapping("CadastroProduto")
    public String CadastroProduto(RequisicaoNovoProduto requicao){

        return "CadastroProduto/CadastroProduto";
    }
    @PostMapping("novo")
    public String novo(RequisicaoNovoProduto requisicao){
        Produto produto = requisicao.toProduto();
         NovoprodutoRepository.save(produto);

        return "CadastroProduto/CadastroProduto";
    }
}
