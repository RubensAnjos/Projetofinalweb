package br.com.ProjetoPI.FifaStore.Model.produto;

import java.util.ArrayList;
import java.util.List;

public class CarrinhoDeCompras {
    private Long id;
    private List<Produto> produtos = new ArrayList<>();

    public List<Produto> getProdutos() {
        return produtos;
    }

    public void setProdutos(List<Produto> produtos) {
        this.produtos = produtos;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
