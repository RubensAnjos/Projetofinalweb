package br.com.ProjetoPI.FifaStore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class  FifaStoreApplication {
	public static void main(String[] args) {
		SpringApplication.run(FifaStoreApplication.class, args);
	}

}
