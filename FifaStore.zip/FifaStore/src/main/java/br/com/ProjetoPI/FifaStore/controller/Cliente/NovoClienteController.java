package br.com.ProjetoPI.FifaStore.controller.Cliente;

import br.com.ProjetoPI.FifaStore.Model.Cliente.Cliente;
import br.com.ProjetoPI.FifaStore.Model.Cliente.Endereco;
import br.com.ProjetoPI.FifaStore.dto.RequisicaoNovoCliente;
import br.com.ProjetoPI.FifaStore.repository.ClienteRepository;
import br.com.ProjetoPI.FifaStore.repository.EnderecoRepository;
import br.com.caelum.stella.validation.CPFValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@Controller
@RequestMapping("CadastroCliente")
public class NovoClienteController {

    @Autowired
    private ClienteRepository NovoClienteRepository;
    @Autowired
    private EnderecoRepository enderecoRepository;

    @GetMapping("CadastroCliente")
    public String CadastroUsuario(RequisicaoNovoCliente requicao ){

        return"CadastroCliente/CadastroCliente";

    }
    private boolean validarCPF(String cpf) {
        CPFValidator cpfValidator = new CPFValidator();
        try {
            cpfValidator.assertValid(cpf);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    Logger logger = LoggerFactory.getLogger(NovoClienteController.class);

    @PostMapping("novo")
    public String novo(@Valid RequisicaoNovoCliente requicao, @RequestParam(value = "faturamento", required = false) boolean faturamento, @RequestParam(value = "entrega", required = false) boolean entrega, @RequestParam(value = "ambos", required = false) boolean ambos, BindingResult result, Model model) {
        if(result.hasErrors()){
            return "CadastroCliente/CadastroCliente";
        }
        // Validar CPF
        if (!validarCPF(requicao.getCpf())) {
            result.rejectValue("cpf", null, "CPF inválido");
            model.addAttribute("mensagemDeErroCPF", "CPF inválido");
            return "CadastroCliente/CadastroCliente";
        }
        // busca um usuário na base de dados com o mesmo e-mail
        Cliente clienteExistente = NovoClienteRepository.findByEmail(requicao.getEmail());
        if(clienteExistente != null){
            // se existir, adiciona uma mensagem de erro ao BindingResult
            result.rejectValue("email", null, "Já existe um usuário cadastrado com esse e-mail");
            model.addAttribute("mensagemDeErro", "Já existe um usuário cadastrado com esse e-mail");
            return "CadastroCliente/CadastroCliente";
        }
        // valida se a senha é igual a do confirmar senha
        if(!requicao.getSenha().equals(requicao.getConfirmarsenha())){
            result.rejectValue("confirmarSenha", null, "A senha e a confirmação de senha não coincidem");
            model.addAttribute("mensagemDeErroSenha", "A senha e a confirmação de senha não coincidem");
            return "CadastroCliente/CadastroCliente";
        }

        Cliente cliente = requicao.toCliente();
        List<Endereco> enderecos = requicao.getEnderecos();

        // Configura a relação Cliente-Endereco
        cliente.setEnderecos(enderecos);
        for (Endereco endereco : enderecos) {
            if (faturamento) {
                endereco.setTipoEndereco("Faturamento");
            }
            if (entrega) {
                endereco.setTipoEndereco("Entrega");
            }
            if (ambos) {
                endereco.setTipoEndereco("Ambos");
            }
            endereco.setCliente(cliente);
        }

        // Salva a instância do Cliente
        NovoClienteRepository.save(cliente);

        // Salva a instância do Endereco
        for (Endereco endereco : enderecos) {
            enderecoRepository.save(endereco);
        }

        return "/LoginCliente";
    }
    

}
