package br.com.ProjetoPI.FifaStore.dto;

import br.com.ProjetoPI.FifaStore.Model.produto.Produto;

public class RequisicaoNovoProduto {

    private String nome;
    private String Descricao;
    private String Especificacao;
    private String codigoProduto;
    private String genero;
    private String marca;
    private String imagem1;
    private String  imagem2;
    private String imagem3;
    private String  imagem4;
    private String  categoria;
    private String  subCategoria;
    private String  tipo;
    private String subProduto;
    private String tamanho;
    private String corDoProduto;
    private double preco;
    private int quantidade;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return Descricao;
    }

    public void setDescricao(String descricao) {
        Descricao = descricao;
    }

    public String getEspecificacao() {
        return Especificacao;
    }

    public void setEspecificacao(String especificacao) {
        Especificacao = especificacao;
    }

    public String getCodigoProduto() {
        return codigoProduto;
    }

    public void setCodigoProduto(String codigoProduto) {
        this.codigoProduto = codigoProduto;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getImagem1() {
        return imagem1;
    }

    public void setImagem1(String imagem1) {
        this.imagem1 = imagem1;
    }

    public String getImagem2() {
        return imagem2;
    }

    public void setImagem2(String imagem2) {
        this.imagem2 = imagem2;
    }

    public String getImagem3() {
        return imagem3;
    }

    public void setImagem3(String imagem3) {
        this.imagem3 = imagem3;
    }

    public String getImagem4() {
        return imagem4;
    }

    public void setImagem4(String imagem4) {
        this.imagem4 = imagem4;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getSubCategoria() {
        return subCategoria;
    }

    public void setSubCategoria(String subCategoria) {
        this.subCategoria = subCategoria;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getSubProduto() {
        return subProduto;
    }

    public void setSubProduto(String subProduto) {
        this.subProduto = subProduto;
    }

    public String getTamanho() {
        return tamanho;
    }

    public void setTamanho(String tamanho) {
        this.tamanho = tamanho;
    }

    public String getCorDoProduto() {
        return corDoProduto;
    }

    public void setCorDoProduto(String corDoProduto) {
        this.corDoProduto = corDoProduto;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public Produto toProduto(){
        Produto produto = new Produto();
        produto.setNome(nome);
        produto.setDescricaoProduto(Descricao);
        produto.setEspecificacao(Especificacao);
        produto.setCodigo(codigoProduto);
        produto.setGenero(genero);
        produto.setMarca(marca);
        produto.setImagem1(imagem1);
        produto.setImagem2(imagem2);
        produto.setImagem3(imagem3);
        produto.setImagem4(imagem4);
        produto.setCategoria(categoria);
        produto.setSubCategoria(subCategoria);
        produto.setTipoProduto(tipo);
        produto.setSubProduto(subProduto);
        produto.setProdutoTamanho(tamanho);
        produto.setCorDoProduto(corDoProduto);
        produto.setPreco(preco);
        produto.setEstoque(quantidade);
        produto.setStatus("ATIVO");
        return produto;
    }

}
