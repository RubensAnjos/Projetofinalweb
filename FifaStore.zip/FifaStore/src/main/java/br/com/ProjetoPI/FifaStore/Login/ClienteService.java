package br.com.ProjetoPI.FifaStore.Login;

import org.springframework.stereotype.Service;
import br.com.ProjetoPI.FifaStore.Model.Cliente.Cliente;
import br.com.ProjetoPI.FifaStore.repository.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;

@Service

public class ClienteService {

    @Autowired
    private ClienteRepository clienteRepository;

    public Cliente autenticarcliente(String email, String senha) {
        return clienteRepository.findByEmailAndSenha(email, senha);
    }
}
