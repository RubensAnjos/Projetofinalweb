package br.com.ProjetoPI.FifaStore.repository;

import br.com.ProjetoPI.FifaStore.Model.Cliente.Cliente;
import br.com.ProjetoPI.FifaStore.Model.Cliente.Endereco;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EnderecoRepository extends JpaRepository<Endereco, Long> {

    List<Endereco> findByCliente(Cliente cliente);
}
