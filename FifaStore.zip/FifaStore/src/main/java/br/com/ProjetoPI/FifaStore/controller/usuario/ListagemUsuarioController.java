package br.com.ProjetoPI.FifaStore.controller.usuario;
import br.com.ProjetoPI.FifaStore.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.ui.Model;
import br.com.ProjetoPI.FifaStore.Model.Usuario.Usuario;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class ListagemUsuarioController {
    @Autowired
    private UsuarioRepository repository;

    // Listagem de Usuario
    @GetMapping("Usuario/ListagemDeUsuarios")
    public String ListagemDeUsuario(Model model, @RequestParam(name = "q", required = false) String query){
        List<Usuario> usuarios;
        if (query != null && !query.isEmpty()) {
            usuarios = repository.findByNomeContainingIgnoreCase(query);
        } else {
            usuarios = repository.findAll();
        }
        model.addAttribute("usuarios",usuarios);
        return "Usuario/ListagemDeUsuarios";
    }
    @GetMapping("Usuario/ListagemDeUsuariosAtivos")
    public String ListagemDeUsuarioAtivos(Model model, @RequestParam(name = "q", required = false) String query){
        List<Usuario> usuarios;
        if (query != null && !query.isEmpty()) {
            usuarios = repository.findByNomeContainingIgnoreCaseAndStatus(query, "ATIVO");
        } else {
            usuarios = repository.findByStatus("ATIVO");
        }
        model.addAttribute("usuarios",usuarios);
        return "Usuario/ListagemDeUsuariosAtivos";
    }
    @GetMapping("Usuario/ListagemDeUsuariosInativos")
    public String ListagemDeUsuarioInativos(Model model, @RequestParam(name = "q", required = false) String query){
        List<Usuario> usuarios;
        if (query != null && !query.isEmpty()) {
            usuarios = repository.findByNomeContainingIgnoreCaseAndStatus(query, "INATIVO");
        } else {
            usuarios = repository.findByStatus("INATIVO");
        }
        model.addAttribute("usuarios",usuarios);
        return "Usuario/ListagemDeUsuariosInativos";
    }
    @GetMapping("/Usuario/AtivarUsuario")
    public String AtivarUsuario(@RequestParam(name = "id") Long id) {
        Usuario usuario = repository.findById(id).orElseThrow(() -> new IllegalArgumentException("Usuário inválido"));
        usuario.setStatus("ATIVO");
        repository.save(usuario);
        return "redirect:/Usuario/ListagemDeUsuarios";
    }
    @GetMapping("/Usuario/InativarUsuario")
    public String InativarUsuario(@RequestParam(name = "id") Long id) {
        Usuario usuario = repository.findById(id).orElseThrow(() -> new IllegalArgumentException("Usuário inválido"));
        usuario.setStatus("INATIVO");
        repository.save(usuario);
        return "redirect:/Usuario/ListagemDeUsuarios";
    }
    @GetMapping("/Usuario/EditaUsuario")
    public String EditarUsuario(@RequestParam(name = "id") Long id, Model model) {
        Usuario usuario = repository.findById(id).orElseThrow(() -> new IllegalArgumentException("Usuário inválido"));
        model.addAttribute("usuario", usuario);
        return "Usuario/FormularioEdicaoUsuario";
    }
    @PostMapping("/Usuario/SalvaUsuario")
    public String salvarUsuario(@ModelAttribute("usuario") Usuario usuario) {

        Usuario usuarioExistente = repository.findById(usuario.getId()).orElse(null);
        if (usuarioExistente != null) {
            usuarioExistente.setNome(usuario.getNome());
            usuarioExistente.setSenha(usuario.getSenha());
            usuarioExistente.setGrupo(usuario.getGrupo());
            // outros campos que você deseja atualizar
            repository.save(usuarioExistente);
        }
        return "redirect:/Usuario/ListagemDeUsuarios";
    }

}


