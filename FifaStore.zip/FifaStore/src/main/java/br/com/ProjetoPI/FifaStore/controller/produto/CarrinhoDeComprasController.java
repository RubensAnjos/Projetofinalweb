    package br.com.ProjetoPI.FifaStore.controller.produto;

    import br.com.ProjetoPI.FifaStore.Model.Cliente.Cliente;
    import br.com.ProjetoPI.FifaStore.Model.Cliente.Endereco;
    import br.com.ProjetoPI.FifaStore.Model.produto.CarrinhoDeCompras;
    import br.com.ProjetoPI.FifaStore.repository.EnderecoRepository;
    import com.fasterxml.jackson.core.JsonProcessingException;
    import com.fasterxml.jackson.core.type.TypeReference;
    import com.fasterxml.jackson.databind.ObjectMapper;
    import jakarta.servlet.http.HttpSession;
    import org.springframework.beans.factory.annotation.Autowired;
    import org.springframework.stereotype.Controller;
    import org.springframework.ui.Model;
    import org.springframework.web.bind.annotation.*;
    import br.com.ProjetoPI.FifaStore.Model.produto.Produto;
    import java.util.ArrayList;
    import java.util.List;
    @Controller
    @RequestMapping("/carrinho")
    public class CarrinhoDeComprasController {

        @Autowired
        private EnderecoRepository enderecoRepository;

        @GetMapping("/carrinho")
        public String exibirCarrinho(Model model, HttpSession session) {
            // Recupera o cliente logado na sessão
            Cliente cliente = (Cliente) session.getAttribute("cliente");

            // Recupera a lista de produtos do carrinho no localStorage
            List<Produto> produtos = new ArrayList<>();
            String carrinho = (String) session.getAttribute("carrinho");
            if (carrinho != null && !carrinho.isEmpty()) {
                ObjectMapper mapper = new ObjectMapper();
                try {
                    produtos = mapper.readValue(carrinho, new TypeReference<List<Produto>>() {});
                } catch (JsonProcessingException e) {
                    e.printStackTrace();
                }
            }

            // Busca os endereços do cliente logado
            List<Endereco> enderecos = enderecoRepository.findByCliente(cliente);

            // Cria um novo carrinho de compras e adiciona os produtos
            CarrinhoDeCompras carrinhoDeCompras = new CarrinhoDeCompras();
            carrinhoDeCompras.setProdutos(produtos);

            // Passa o carrinho de compras, o endereço e o cliente para a página do carrinho
            model.addAttribute("carrinhoDeCompras", carrinhoDeCompras);
            model.addAttribute("enderecoCliente", enderecos);
            model.addAttribute("cliente", cliente);

            return "/carrinho/carrinho";
        }

        @ModelAttribute("carrinhoDeCompras")
        public CarrinhoDeCompras getCarrinhoDeCompras() {
            return new CarrinhoDeCompras();
        }
        @GetMapping("/carrinho/finalizarCompra")
        public String FinalizarCompra(){
            return "finalizarCompra";
        }

    }
