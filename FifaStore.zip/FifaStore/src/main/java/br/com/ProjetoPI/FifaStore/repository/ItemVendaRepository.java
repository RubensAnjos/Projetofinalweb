package br.com.ProjetoPI.FifaStore.repository;

import br.com.ProjetoPI.FifaStore.Model.produto.ItemVenda;
import br.com.ProjetoPI.FifaStore.Model.produto.Venda;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ItemVendaRepository extends JpaRepository<ItemVenda, Long> {
    List<ItemVenda> findByVenda(Venda venda);
}
