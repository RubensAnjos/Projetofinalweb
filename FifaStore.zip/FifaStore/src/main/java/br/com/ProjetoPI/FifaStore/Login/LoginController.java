package br.com.ProjetoPI.FifaStore.Login;

import br.com.ProjetoPI.FifaStore.Model.Cliente.Cliente;
import br.com.ProjetoPI.FifaStore.Model.Usuario.Usuario;
import jakarta.servlet.http.HttpSession;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import br.com.ProjetoPI.FifaStore.repository.ClienteRepository;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.ui.Model;



@Controller
public class LoginController {

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private ClienteService clienteService;

    @Autowired
    private ClienteRepository clienteRepository;

    @GetMapping("/Login")
    public String showLoginForm() {
        return "/Login";
    }

    @GetMapping("/LoginCliente")
    public String showLoginFormCliente() {
        return "/LoginCliente";
    }

    // Login backoffice
    @PostMapping("/Login")
    public String processLoginForm(@RequestParam String email, @RequestParam String senha, Model model, HttpSession session) {

        Usuario usuario = usuarioService.autenticarUsuario(email, senha);
        if (usuario != null) {
            if (usuario.getGrupo().equals("ADIMINISTRATIVO")) {
                UserDetails userDetails = new UserDetails(usuario.getNome(), "Administrativo");
                session.setAttribute("userDetails", userDetails);
                return "redirect:/ADM/Index";
            } else if (usuario.getGrupo().equals("ESTOQUISTA")) {
                UserDetails userDetails = new UserDetails(usuario.getNome(), "Estoquista");
                session.setAttribute("userDetails", userDetails);
                return "redirect:/ESTOQUISTA/Index";
            } else {
                // grupo inválido, exibe mensagem de erro
                model.addAttribute("erro", "Grupo inválido");
                return "/Login";
            }
        } else {
            // usuário não autenticado, exibe mensagem de erro
            model.addAttribute("mensagemDeErroAcesso", "Email ou senha inválidos");
            return "/Login";
        }
    }

    @GetMapping("/ADM/Index")
    public String LoginADM(Model model, HttpSession session) {
        UserDetails userDetails = (UserDetails) session.getAttribute("userDetails");
        if (userDetails != null && userDetails.getRole().equals("Administrativo")) {
            model.addAttribute("username", userDetails.getUsername());
            return "/ADM/Index";
        } else {
            return "redirect:/Login";
        }
    }

    @GetMapping("/ESTOQUISTA/Index")
    public String LoginEstoquista(Model model, HttpSession session) {
        UserDetails userDetails = (UserDetails) session.getAttribute("userDetails");
        if (userDetails != null && userDetails.getRole().equals("Estoquista")) {
            model.addAttribute("username", userDetails.getUsername());
            return "/ESTOQUISTA/Index";
        } else {
            return "redirect:/Login";
        }
    }


    @PostMapping("/LoginCliente")
    public String processLoginFormCliente(@RequestParam String email, @RequestParam String senha, Model model, HttpSession session) {

        Cliente cliente = clienteService.autenticarcliente(email, senha);
        if (cliente != null) {
            UserDetails userDetails = new UserDetails(cliente.getNomeCliente(), "Cliente");
            session.setAttribute("userDetails", userDetails);

            // adiciona dados do cliente no HttpSession
            session.setAttribute("cliente", cliente);

            return "redirect:/CLIENTE/IndexCliente";
        } else {
            // usuário não autenticado, exibe mensagem de erro
            model.addAttribute("mensagemDeErroAcesso", "Email ou senha inválidos");
            return "/LoginCliente";
        }
    }

    @GetMapping("/Logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/Index";
    }
}
