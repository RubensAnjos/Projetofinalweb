package br.com.ProjetoPI.FifaStore.controller.Index;

import br.com.ProjetoPI.FifaStore.Model.produto.Produto;
import br.com.ProjetoPI.FifaStore.repository.ProdutoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class Index {
    @Autowired
    private ProdutoRepository repository;

    @GetMapping("/Index")
    public String Home(Model model, @RequestParam(name = "q", required = false) String query,
                       @RequestParam(name = "page", defaultValue = "0") int page) {
        int produtosPorPagina = 6;
        Pageable pageable = PageRequest.of(page, produtosPorPagina);
        Page<Produto> produtos;
        if (query != null && !query.isEmpty()) {
            produtos = repository.findByNomeContainingIgnoreCase(query, pageable);
        } else {
            produtos = repository.findByStatus("ATIVO", pageable);
        }
        model.addAttribute("produtos", produtos.getContent());
        model.addAttribute("totalDePaginas", produtos.getTotalPages());
        model.addAttribute("paginaAtual", page);
        return "/Index";
    }

    @GetMapping("/CLIENTE/IndexCliente")
    public String HomeCliente(Model model, @RequestParam(name = "q", required = false) String query,
                              @RequestParam(name = "page", defaultValue = "0") int page) {
        int produtosPorPagina = 6;
        Pageable pageable = PageRequest.of(page, produtosPorPagina);
        Page<Produto> produtos;
        if (query != null && !query.isEmpty()) {
            produtos = repository.findByNomeContainingIgnoreCase(query, pageable);
        } else {
            produtos = repository.findByStatus("ATIVO", pageable);
        }
        model.addAttribute("produtos", produtos.getContent());
        model.addAttribute("totalDePaginas", produtos.getTotalPages());
        model.addAttribute("paginaAtual", page);
        return "CLIENTE/IndexCliente";
    }

}
