package br.com.ProjetoPI.FifaStore.dto;

import br.com.ProjetoPI.FifaStore.Model.Usuario.Usuario;

public class RequisicaoNovoUsuario {

    private String nome;
    private String email;
    private String senha;
    private String confirmarSenha;
    private String grupo;
    private String cpf;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getConfirmarSenha() {
        return confirmarSenha;
    }

    public void setConfirmarSenha(String confirmarSenha) {
        this.confirmarSenha = confirmarSenha;
    }

    public String getGrupo() {
        return grupo;
    }

    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }

    public Usuario toUsuario() {
        Usuario usuario = new Usuario();
        usuario.setNome(nome);
        usuario.setEmail(email);
        usuario.setSenha(senha);
        usuario.setConfirmarSenha(confirmarSenha);
        usuario.setStatus("ATIVO");
        usuario.setGrupo(grupo);
        usuario.setCPF(cpf);
        return usuario;
    }

}
