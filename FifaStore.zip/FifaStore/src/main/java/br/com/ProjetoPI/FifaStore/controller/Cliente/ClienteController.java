package br.com.ProjetoPI.FifaStore.controller.Cliente;

import br.com.ProjetoPI.FifaStore.Model.Cliente.Cliente;
import br.com.ProjetoPI.FifaStore.Model.Cliente.Endereco;
import br.com.ProjetoPI.FifaStore.Model.produto.CarrinhoDeCompras;
import br.com.ProjetoPI.FifaStore.Model.produto.ItemVenda;
import br.com.ProjetoPI.FifaStore.Model.produto.Produto;
import br.com.ProjetoPI.FifaStore.Model.produto.Venda;
import br.com.ProjetoPI.FifaStore.repository.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class ClienteController {

    @Autowired
    private ProdutoRepository repository;

    @Autowired
    private ClienteRepository clienteRepository;

    @Autowired
    private EnderecoRepository enderecoRepository;

    @Autowired
    private VendaRepository vendaRepository;

    @Autowired
    private ItemVendaRepository itemVendaRepository;

    @GetMapping("/CLIENTE/DetalheDoProduto")
    public String DetalheDoProduto(@RequestParam(name="id")Long id, Model model) {
        Produto produto = repository.findById(id).orElseThrow(() -> new IllegalArgumentException("ID do produto inválido: " + id));
        model.addAttribute("produto", produto);
        return "CLIENTE/DetalheDoProduto";
    }
    @GetMapping("/CLIENTE/MeuPerfil")
    @Transactional
    public String meuPerfil(Model model, HttpSession session) {
        Cliente cliente = (Cliente) session.getAttribute("cliente");
        cliente = clienteRepository.findById(cliente.getId()).orElse(null);
        model.addAttribute("cliente", cliente);
        model.addAttribute("editMode", false);
        return "/CLIENTE/MeuPerfil";
    }

    @PostMapping("/CLIENTE/MeuPerfil/salvar")
    public String salvarPerfil(@RequestParam("id") Long id,
                               @RequestParam("nomeCliente") String nomeCliente,
                               @RequestParam("dataDeNascimento") String dataDeNascimento,
                               @RequestParam("senha") String senha,
                               @RequestParam("telefone") String telefone,
                               @RequestParam("celular") String celular) {
        Cliente clienteExistente = clienteRepository.findById(id).orElse(null);
        if(clienteExistente!=null){
            clienteExistente.setNomeCliente(nomeCliente);
            clienteExistente.setDataDeNascimento(dataDeNascimento);
            clienteExistente.setSenha(senha);
            clienteExistente.setTelefone(telefone);
            clienteExistente.setCelular(celular);
            clienteRepository.save(clienteExistente);
        }
        return "redirect:/CLIENTE/MeuPerfil";
    }

    @GetMapping("/CLIENTE/MeuPerfil/editar")
    public String editarPerfil(Model model, HttpSession session) {
        Cliente cliente = (Cliente) session.getAttribute("cliente");
        cliente = clienteRepository.findById(cliente.getId()).orElse(null);
        model.addAttribute("cliente", cliente);
        model.addAttribute("editMode", true);
        return "/CLIENTE/MeuPerfil";
    }

    @GetMapping("/CLIENTE/MeuPerfil/adicionarEndereco")
    public String adicionarEndereco(Model model, HttpSession session) {
        Cliente cliente = (Cliente) session.getAttribute("cliente");
        cliente = clienteRepository.findById(cliente.getId()).orElse(null);
        model.addAttribute("cliente", cliente);
        model.addAttribute("editMode", true);
        model.addAttribute("novoEndereco", true); // Adiciona um novo atributo para indicar que é um novo endereço
        return "/CLIENTE/MeuPerfil";
    }

    @PostMapping("/CLIENTE/MeuPerfil/salvarEndereco")
    public String salvarEndereco(@RequestParam("cep") String cep,
                                 @RequestParam("endereco") String endereco,
                                 @RequestParam("bairro") String bairro,
                                 @RequestParam("cidade") String cidade,
                                 @RequestParam("numero") String numero,
                                 @RequestParam("complemento") String complemento,
                                 @RequestParam("estado") String estado,
                                 HttpSession session) {
        Cliente cliente = (Cliente) session.getAttribute("cliente");
        if (cliente != null) {
            Endereco novoEndereco = new Endereco();
            novoEndereco.setCep(cep);
            novoEndereco.setEndereco(endereco);
            novoEndereco.setBairro(bairro);
            novoEndereco.setCidade(cidade);
            novoEndereco.setNumero(numero);
            novoEndereco.setComplemento(complemento);
            novoEndereco.setEstado(estado);
            novoEndereco.setCliente(cliente);
            cliente.getEnderecos().add(novoEndereco);
            enderecoRepository.save(novoEndereco);
            clienteRepository.save(cliente);
        }
        return "redirect:/CLIENTE/MeuPerfil";
    }
    @GetMapping("/CLIENTE/MeusPedidos")
    public String getVendasCliente(Model model, HttpSession session) {
        Cliente cliente = (Cliente) session.getAttribute("cliente");
        cliente = clienteRepository.findById(cliente.getId()).orElse(null);

        if (cliente != null) {
            // Buscar as vendas do cliente
            List<Venda> vendasList = vendaRepository.findByCliente(cliente);

            // Adicionar a lista de vendas ao modelo para exibição na view
            model.addAttribute("vendasList", vendasList);

            return "CLIENTE/MeusPedidos";
        }

        return "erro"; // Trate de acordo com o seu caso se o cliente não for encontrado
    }


    @GetMapping("/CLIENTE/DetalheDaCompra")
    public String detalheDaVendaCliente(@RequestParam("id") Long vendaId, Model model) {
        // Busque a venda pelo ID no banco de dados
        Venda venda = vendaRepository.findById(vendaId).orElse(null);

        if (venda != null) {
            // Busque os itens de venda relacionados à venda
            List<ItemVenda> itensVenda = itemVendaRepository.findByVenda(venda);

            // Adicione a venda e os itens de venda ao modelo para exibição na página de detalhes
            model.addAttribute("venda", venda);
            model.addAttribute("itensVenda", itensVenda);

            return "/CLIENTE/DetalheDaCompra";
        }

        return "erro"; // Trate de acordo com o seu caso se a venda não for encontrada
    }


}
