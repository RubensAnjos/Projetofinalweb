package br.com.ProjetoPI.FifaStore.controller.produto;

import br.com.ProjetoPI.FifaStore.Model.Cliente.Cliente;
import br.com.ProjetoPI.FifaStore.Model.Cliente.Endereco;
import br.com.ProjetoPI.FifaStore.Model.produto.ItemVenda;
import br.com.ProjetoPI.FifaStore.Model.produto.Produto;
import br.com.ProjetoPI.FifaStore.Model.produto.Venda;
import br.com.ProjetoPI.FifaStore.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Controller
public class FinalizarCompraController {

    @Autowired
    private VendaRepository vendaRepository;

    @Autowired
    private ProdutoRepository produtoRepository;

    @Autowired
    private ItemVendaRepository itemVendaRepository;

    @Autowired
    private ClienteRepository clienteRepository;
    @Autowired
    private EnderecoRepository enderecoRepository;
    public String gerarNumeroPedido() {
        Random random = new Random();
        int numero = random.nextInt(9000) + 1000; // Gera um número aleatório entre 1000 e 9999
        String numeroPedido = "#P" + numero;
        return numeroPedido;
    }

    @PostMapping("/finalizarCompra")
    public String salvarVenda(
            @RequestParam("idCliente") Long idCliente,
            @RequestParam("statusPedido") String statusPedido,
            @RequestParam("enderecoId") Long enderecoId,
            @RequestParam("valorTotal") double valorTotal,
            @RequestParam("formaPagamento") String formaPagamento,
            @RequestParam("frete") String tipoFrete,
            @RequestParam("produtos") List<Long> produtos,
            @RequestParam("quantidades") List<Integer> quantidades
    ) {

        // Gerar o número do pedido
        String numeroPedido = gerarNumeroPedido();
        String dataPedidoString = LocalDate.now().toString();

        int diasUteisFrete;
        double valorFrete = 0;
        if (tipoFrete.equals("sedex")) {
            diasUteisFrete = 2;
            valorFrete=10.0;
        } else if (tipoFrete.equals("pac")) {
            diasUteisFrete = 7;
            valorFrete=7.5;
        } else if (tipoFrete.equals("transportadora")) {
            diasUteisFrete = 2;
            valorFrete=15.0;
        } else {
            diasUteisFrete = 0;
        }

        // Buscar o cliente pelo ID
        Cliente cliente = clienteRepository.findById(idCliente).orElse(null);

        // Buscar o endereço pelo ID
        Endereco endereco = enderecoRepository.findById(enderecoId).orElse(null);

        if (cliente == null || endereco == null) {
            // Cliente ou endereço não encontrado
            return "erro"; // Trate de acordo com o seu caso
        }

        // Salvar a venda no banco de dados
        Venda venda = new Venda();
        venda.setCliente(cliente);
        venda.setNumeroPedido(numeroPedido);
        venda.setStatusPedido(statusPedido);
        venda.setEndereco(endereco);
        venda.setValorFrete(valorFrete);
        venda.setDiasUteisFrete(diasUteisFrete);
        venda.setValorTotal(valorTotal);
        venda.setFormaPagamento(formaPagamento);
        venda.setTipoFrete(tipoFrete);
        venda.setDataPedido(dataPedidoString);
        // Preencha os demais atributos da venda

        // Salvar os itens de venda no banco de dados
        List<ItemVenda> itensVenda = new ArrayList<>();
        for (int i = 0; i < produtos.size(); i++) {
            Long produtoId = produtos.get(i);
            Integer quantidade = quantidades.get(i);

            // Buscar o produto pelo ID
            Produto produto = produtoRepository.findById(produtoId).orElse(null);

            if (produto != null) {
                ItemVenda itemVenda = new ItemVenda();
                itemVenda.setVenda(venda);
                itemVenda.setIdProduto(produtoId);
                itemVenda.setQuantidade(quantidade);
                itemVenda.setValorTotal(produto.getPreco() * quantidade);
                itemVenda.setPrecoUnitario(produto.getPreco());

                itensVenda.add(itemVenda);
            }
        }

        venda.setItens(itensVenda);

        vendaRepository.save(venda);

        // Salvar os itens de venda no banco de dados
        itemVendaRepository.saveAll(itensVenda);

        return "/CLIENTE/MeusPedidos";
    }

    @GetMapping("/ESTOQUISTA/ListagemDePedidos")
    public String getVendas(Model model) {

        // Buscar todas as vendas
        List<Venda> vendasList = vendaRepository.findAll();

        // Adicionar a lista de vendas ao modelo para exibição na view
        model.addAttribute("vendasList", vendasList);

        return "ESTOQUISTA/ListagemDePedidos";
    }

    @GetMapping("/ESTOQUISTA/AprovarPagamentoVenda")
    public String aprovarPagamentoVenda(@RequestParam("id") Long vendaId) {
        // Busque a venda pelo ID no banco de dados
        Venda venda = vendaRepository.findById(vendaId).orElse(null);

        if (venda != null) {
            // Atualize o status da venda para "Aprovado"
            venda.setStatusPedido("Pagamento com Sucesso");
            vendaRepository.save(venda);
        }

        return "redirect:/ESTOQUISTA/ListagemDePedidos";
    }

    @GetMapping("/ESTOQUISTA/RecusarPagamentoVenda")
    public String recusarPagamentoVenda(@RequestParam("id") Long vendaId) {
        // Busque a venda pelo ID no banco de dados
        Venda venda = vendaRepository.findById(vendaId).orElse(null);


        if (venda != null) {
            // Atualize o status da venda para "Recusado"
            venda.setStatusPedido("Pagamento Rejeitado");
            vendaRepository.save(venda);
        }

        return "redirect:/ESTOQUISTA/ListagemDePedidos";
    }
    @GetMapping("/ESTOQUISTA/aguardandoRetirada")
    public String aguardandoRetirada(@RequestParam("id") Long vendaId) {
        // Busque a venda pelo ID no banco de dados
        Venda venda = vendaRepository.findById(vendaId).orElse(null);


        if (venda != null) {
            // Atualize o status da venda para "Recusado"
            venda.setStatusPedido("Aguardando Retirada");
            vendaRepository.save(venda);
        }

        return "redirect:/ESTOQUISTA/ListagemDePedidos";
    }

    @GetMapping("/ESTOQUISTA/emTransito")
    public String emTransito(@RequestParam("id") Long vendaId) {
        // Busque a venda pelo ID no banco de dados
        Venda venda = vendaRepository.findById(vendaId).orElse(null);


        if (venda != null) {
            // Atualize o status da venda para "Recusado"
            venda.setStatusPedido("Em Transito");
            vendaRepository.save(venda);
        }

        return "redirect:/ESTOQUISTA/ListagemDePedidos";
    }

    @GetMapping("/ESTOQUISTA/entregue")
    public String entregue(@RequestParam("id") Long vendaId) {
        // Busque a venda pelo ID no banco de dados
        Venda venda = vendaRepository.findById(vendaId).orElse(null);


        if (venda != null) {
            // Atualize o status da venda para "Recusado"
            venda.setStatusPedido("Entregue");
            vendaRepository.save(venda);
        }

        return "redirect:/ESTOQUISTA/ListagemDePedidos";
    }

    @GetMapping("/ESTOQUISTA/DetalheDaVenda")
    public String detalheDaVenda(@RequestParam("id") Long vendaId, Model model) {
        // Busque a venda pelo ID no banco de dados
        Venda venda = vendaRepository.findById(vendaId).orElse(null);

        if (venda != null) {
            // Busque os itens de venda relacionados à venda
            List<ItemVenda> itensVenda = itemVendaRepository.findByVenda(venda);

            // Adicione a venda e os itens de venda ao modelo para exibição na página de detalhes
            model.addAttribute("venda", venda);
            model.addAttribute("itensVenda", itensVenda);

            return "/ESTOQUISTA/DetalheDaVenda";
        }

        return "erro"; // Trate de acordo com o seu caso se a venda não for encontrada
    }


}


