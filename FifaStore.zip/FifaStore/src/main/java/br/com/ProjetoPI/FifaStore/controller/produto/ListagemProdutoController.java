package br.com.ProjetoPI.FifaStore.controller.produto;

import br.com.ProjetoPI.FifaStore.Model.Usuario.Usuario;
import br.com.ProjetoPI.FifaStore.Model.produto.CarrinhoDeCompras;
import br.com.ProjetoPI.FifaStore.Model.produto.Produto;
import br.com.ProjetoPI.FifaStore.repository.ProdutoRepository;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class ListagemProdutoController {

    @Autowired
    private ProdutoRepository repository;

    // EXCLUISVO PARA O PERFIL ADM
    @GetMapping("Produto/ListagemDeProdutos")
    public String ListagemDeProduto(Model model,
                                    @RequestParam(name = "q", required = false) String query,
                                    @RequestParam(name = "page", defaultValue = "0") int page) {
        int produtosPorPagina = 10;
        Pageable pageable = PageRequest.of(page, produtosPorPagina);
        Page<Produto> produtos;
        if (query != null && !query.isEmpty()) {
            produtos = repository.findByNomeContainingIgnoreCase(query, pageable);
        } else {
            produtos = repository.findAll(pageable);
        }
        model.addAttribute("produtos", produtos.getContent());
        model.addAttribute("totalDePaginas", produtos.getTotalPages());
        model.addAttribute("paginaAtual", page);
        return "Produto/ListagemDeProdutos";
    }
    @GetMapping("Produto/ListagemDeProdutosAtivos")
    public String ListagemDeProdutoAtivos(Model model,
                                    @RequestParam(name = "q", required = false) String query,
                                    @RequestParam(name = "page", defaultValue = "0") int page) {
        int produtosPorPagina = 10;
        Pageable pageable = PageRequest.of(page, produtosPorPagina);
        Page<Produto> produtos;
        if (query != null && !query.isEmpty()) {
            produtos = repository.findByNomeContainingIgnoreCase(query, pageable);
        } else {
            produtos = repository.findByStatus("ATIVO", pageable);
        }
        model.addAttribute("produtos", produtos.getContent());
        model.addAttribute("totalDePaginas", produtos.getTotalPages());
        model.addAttribute("paginaAtual", page);
        return "Produto/ListagemDeProdutosAtivos";
    }

    @GetMapping("Produto/ListagemDeProdutosInativos")
    public String ListagemDeProdutoInativos(Model model,
                                          @RequestParam(name = "q", required = false) String query,
                                          @RequestParam(name = "page", defaultValue = "0") int page) {
        int produtosPorPagina = 10;
        Pageable pageable = PageRequest.of(page, produtosPorPagina);
        Page<Produto> produtos;
        if (query != null && !query.isEmpty()) {
            produtos = repository.findByNomeContainingIgnoreCase(query, pageable);
        } else {
            produtos = repository.findByStatus("INATIVO", pageable);
        }
        model.addAttribute("produtos", produtos.getContent());
        model.addAttribute("totalDePaginas", produtos.getTotalPages());
        model.addAttribute("paginaAtual", page);
        return "Produto/ListagemDeProdutosInativos";
    }
    @GetMapping("/Produto/AtivarProduto")
    public String AtivarProduto(@RequestParam(name = "id") Long id) {
        Produto produto = repository.findById(id).orElseThrow(() -> new IllegalArgumentException("Produto inválido"));
        produto.setStatus("ATIVO");
        repository.save(produto);
        return "redirect:/Produto/ListagemDeProdutos";
    }
    @GetMapping("/Produto/InativarProduto")
    public String InativarProduto(@RequestParam(name = "id") Long id) {
        Produto produto = repository.findById(id).orElseThrow(() -> new IllegalArgumentException("Produto inválido"));
        produto.setStatus("INATIVO");
        repository.save(produto);
        return "redirect:/Produto/ListagemDeProdutos";
    }
    @GetMapping("/Produto/EditaProduto")
    public String EditarProduto(@RequestParam(name = "id") Long id, Model model) {
        Produto produto = repository.findById(id).orElseThrow(() -> new IllegalArgumentException("Produto inválido"));
        model.addAttribute("produto", produto);
        return "Produto/FormularioEdicaoProduto";
    }
    @PostMapping("/Produto/atualizaProduto")
    public String atualizarProduto( @ModelAttribute("produto") Produto produtoAtualizado) {
        Produto produtoAntigo = repository.findById(produtoAtualizado.getId()).orElseThrow(() -> new IllegalArgumentException("Produto inválido!"));
        if(produtoAtualizado.getEstoque()>0){
        produtoAntigo.setNome(produtoAtualizado.getNome());
        produtoAntigo.setDescricaoProduto(produtoAtualizado.getDescricaoProduto());
        produtoAntigo.setEspecificacao(produtoAtualizado.getEspecificacao());
        produtoAntigo.setCodigo(produtoAtualizado.getCodigo());
        produtoAntigo.setCategoria(produtoAtualizado.getCategoria());
        produtoAntigo.setEstoque(produtoAtualizado.getEstoque());
        produtoAntigo.setGenero(produtoAtualizado.getGenero());
        produtoAntigo.setImagem1(produtoAtualizado.getImagem1());
        produtoAntigo.setImagem2(produtoAtualizado.getImagem2());
        produtoAntigo.setImagem3(produtoAtualizado.getImagem3());
        produtoAntigo.setImagem4(produtoAtualizado.getImagem4());
        produtoAntigo.setMarca(produtoAtualizado.getMarca());
        produtoAntigo.setPreco(produtoAtualizado.getPreco());
        produtoAntigo.setProdutoTamanho(produtoAtualizado.getProdutoTamanho());
        produtoAntigo.setSubCategoria(produtoAtualizado.getSubCategoria());
        produtoAntigo.setSubProduto(produtoAtualizado.getSubProduto());
        produtoAntigo.setTipoProduto(produtoAtualizado.getTipoProduto());
        produtoAntigo.setCorDoProduto(produtoAtualizado.getCorDoProduto());
        repository.save(produtoAntigo);
        } else{
            produtoAntigo.setNome(produtoAtualizado.getNome());
            produtoAntigo.setDescricaoProduto(produtoAtualizado.getDescricaoProduto());
            produtoAntigo.setEspecificacao(produtoAtualizado.getEspecificacao());
            produtoAntigo.setCodigo(produtoAtualizado.getCodigo());
            produtoAntigo.setCategoria(produtoAtualizado.getCategoria());
            produtoAntigo.setEstoque(produtoAtualizado.getEstoque());
            produtoAntigo.setGenero(produtoAtualizado.getGenero());
            produtoAntigo.setImagem1(produtoAtualizado.getImagem1());
            produtoAntigo.setImagem2(produtoAtualizado.getImagem2());
            produtoAntigo.setImagem3(produtoAtualizado.getImagem3());
            produtoAntigo.setImagem4(produtoAtualizado.getImagem4());
            produtoAntigo.setMarca(produtoAtualizado.getMarca());
            produtoAntigo.setPreco(produtoAtualizado.getPreco());
            produtoAntigo.setProdutoTamanho(produtoAtualizado.getProdutoTamanho());
            produtoAntigo.setSubCategoria(produtoAtualizado.getSubCategoria());
            produtoAntigo.setSubProduto(produtoAtualizado.getSubProduto());
            produtoAntigo.setTipoProduto(produtoAtualizado.getTipoProduto());
            produtoAntigo.setCorDoProduto(produtoAtualizado.getCorDoProduto());
            produtoAntigo.setStatus("INATIVO");
            repository.save(produtoAntigo);
        }

        return "/Produto/DetalheDoProduto";
}
    @GetMapping("/Produto/DetalheDoProduto")
    public String DetalheDoProduto(@RequestParam (name="id")Long id, Model model) {
        Produto produto = repository.findById(id).orElseThrow(() -> new IllegalArgumentException("ID do produto inválido: " + id));
        model.addAttribute("produto", produto);
        return "Produto/DetalheDoProduto";
    }

      // EXCLUSIVO PARA O PERFIL ESTOQUISTA

    @GetMapping("ESTOQUISTA/DetalheDoProduto")
    public String DetalheDoProdutoEstoquista(@RequestParam (name="id")Long id, Model model) {
        Produto produto = repository.findById(id).orElseThrow(() -> new IllegalArgumentException("ID do produto inválido: " + id));
        model.addAttribute("produto", produto);
        return "ESTOQUISTA/DetalheDoProduto";
    }
    @GetMapping("ESTOQUISTA/EditarProduto")
    public String EditarProdutoEstoquista(@RequestParam(name = "id") Long id, Model model) {
        Produto produto = repository.findById(id).orElseThrow(() -> new IllegalArgumentException("Usuário inválido"));
        model.addAttribute("produto", produto);
        return "ESTOQUISTA/FormularioEdicaoProduto";
    }
    @GetMapping("ESTOQUISTA/ListagemDeProdutos")
    public String ListagemDeProdutoEstoquista(Model model, @RequestParam(name = "q", required = false) String query){
        List<Produto> produtos;
        if (query != null && !query.isEmpty()) {
            produtos = repository.findByNomeContainingIgnoreCase(query);
        } else {
            produtos = repository.findAll();
        }
        model.addAttribute("produtos",produtos);
        return "ESTOQUISTA/ListagemDeProdutos";
    }



}
