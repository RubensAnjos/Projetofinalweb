package br.com.ProjetoPI.FifaStore.Login;

public class UserDetails {

    private String username;
    private String role;

    public UserDetails(String username, String role) {
        this.username = username;
        this.role = role;
    }

    public String getUsername() {
        return username;
    }

    public String getRole() {
        return role;
    }
}
