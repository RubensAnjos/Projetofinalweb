package br.com.ProjetoPI.FifaStore.controller.usuario;
import br.com.caelum.stella.validation.CPFValidator;
import br.com.ProjetoPI.FifaStore.Model.Usuario.Usuario;
import br.com.ProjetoPI.FifaStore.dto.RequisicaoNovoUsuario;
import br.com.ProjetoPI.FifaStore.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import javax.validation.Valid;
import org.springframework.ui.Model;

@Controller
@RequestMapping("CadastroUsuario")
public class NovoUsuarioController {

    @Autowired
    private UsuarioRepository NovousuarioRepository;
    @GetMapping("CadastroUsuario")
    public String CadastroUsuario(RequisicaoNovoUsuario requicao ){

        return"CadastroUsuario/CadastroUsuario";

    }
    private boolean validarCPF(String cpf) {
        CPFValidator cpfValidator = new CPFValidator();
        try {
            cpfValidator.assertValid(cpf);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    @PostMapping("novo")
    public String novo(@Valid RequisicaoNovoUsuario requicao, BindingResult result, Model model){
        if(result.hasErrors()){
            return "CadastroUsuario/CadastroUsuario";
        }
        // Validar CPF
        if (!validarCPF(requicao.getCpf())) {
            result.rejectValue("cpf", null, "CPF inválido");
            model.addAttribute("mensagemDeErroCPF", "CPF inválido");
            return "CadastroUsuario/CadastroUsuario";
        }
        // busca um usuário na base de dados com o mesmo e-mail
        Usuario usuarioExistente = NovousuarioRepository.findByEmail(requicao.getEmail());
        if(usuarioExistente != null){
            // se existir, adiciona uma mensagem de erro ao BindingResult
            result.rejectValue("email", null, "Já existe um usuário cadastrado com esse e-mail");
            model.addAttribute("mensagemDeErro", "Já existe um usuário cadastrado com esse e-mail");
            return "CadastroUsuario/CadastroUsuario";
        }
        // valida se a senha é igual a do confirmar senha
        if(!requicao.getSenha().equals(requicao.getConfirmarSenha())){
            result.rejectValue("confirmarSenha", null, "A senha e a confirmação de senha não coincidem");
            model.addAttribute("mensagemDeErroSenha", "A senha e a confirmação de senha não coincidem");
            return "CadastroUsuario/CadastroUsuario";
        }

        Usuario usuario = requicao.toUsuario();
        NovousuarioRepository.save(usuario);
        return "CadastroUsuario/CadastroUsuario";
    }

}
