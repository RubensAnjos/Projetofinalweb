package br.com.ProjetoPI.FifaStore.Login;

import org.springframework.stereotype.Service;
import br.com.ProjetoPI.FifaStore.Model.Usuario.Usuario;
import br.com.ProjetoPI.FifaStore.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    public Usuario autenticarUsuario(String email, String senha) {
        return usuarioRepository.findByEmailAndSenha(email, senha);
    }
}
