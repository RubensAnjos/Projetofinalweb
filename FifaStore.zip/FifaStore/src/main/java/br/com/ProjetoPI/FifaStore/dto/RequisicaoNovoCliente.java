package br.com.ProjetoPI.FifaStore.dto;

import br.com.ProjetoPI.FifaStore.Model.Cliente.Cliente;
import br.com.ProjetoPI.FifaStore.Model.Cliente.Endereco;
import br.com.ProjetoPI.FifaStore.Model.Usuario.Usuario;

import java.util.ArrayList;
import java.util.List;

public class RequisicaoNovoCliente {

    private String nome;
    private String cpf;
    private String dataDeNascimento;
    private String telefone;
    private String celular;
    private String genero;
    private String email;
    private String senha;

    private String confirmarsenha;

    private List<Endereco> enderecos;


    public RequisicaoNovoCliente() {
        this.enderecos = new ArrayList<>();
        this.enderecos.add(new Endereco());
    }


    public List<Endereco> getEnderecos() {
        return enderecos;
    }

    public void setEnderecos(List<Endereco> enderecos) {
        this.enderecos = enderecos;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nomeCliente) {
        this.nome = nomeCliente;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getDataDeNascimento() {
        return dataDeNascimento;
    }

    public void setDataDeNascimento(String dataDeNascimento) {
        this.dataDeNascimento = dataDeNascimento;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }


    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getConfirmarsenha() {
        return confirmarsenha;
    }

    public void setConfirmarsenha(String confirmarsenha) {
        this.confirmarsenha = confirmarsenha;
    }

    public Cliente toCliente() {
        Cliente cliente = new Cliente();

        cliente.setNomeCliente(nome);
        cliente.setCpf(cpf);
        cliente.setDataDeNascimento(dataDeNascimento);
        cliente.setTelefone(telefone);
        cliente.setCelular(celular);
        cliente.setGenero(genero);
        cliente.setEmail(email);
        cliente.setSenha (senha);
        cliente.setConfirmarsenha(confirmarsenha);
        List<Endereco> enderecos = new ArrayList<>();
        for (int i = 0; i < this.enderecos.size(); i++) {
            Endereco endereco = new Endereco();
            endereco.setCep(this.enderecos.get(i).getCep());
            endereco.setEndereco(this.enderecos.get(i).getEndereco());
            endereco.setBairro(this.enderecos.get(i).getBairro());
            endereco.setCidade(this.enderecos.get(i).getCidade());
            endereco.setNumero(this.enderecos.get(i).getNumero());
            endereco.setComplemento(this.enderecos.get(i).getComplemento());
            endereco.setEstado(this.enderecos.get(i).getEstado());
            enderecos.add(endereco);
        }

        cliente.setEnderecos(enderecos);
        return cliente;
    }


}
