package br.com.ProjetoPI.FifaStore.controller.usuario;

import br.com.ProjetoPI.FifaStore.Model.Usuario.Usuario;
import br.com.ProjetoPI.FifaStore.repository.UsuarioRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.ui.Model;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;

public class ListagemUsuarioControllerTest {

    @Mock
    private UsuarioRepository usuarioRepository;

    @InjectMocks
    private ListagemUsuarioController listagemUsuarioController;

    @Test
    public void testListagemDeUsuario() {
        MockitoAnnotations.openMocks(this);

        // Criar uma lista fictícia de usuários
        List<Usuario> usuariosList = Collections.singletonList(new Usuario());

        // Configurar o comportamento do repositório de usuários
        when(usuarioRepository.findAll()).thenReturn(usuariosList);

        // Criar um modelo fictício
        Model model = mock(Model.class);

        // Chamar o método de teste
        String viewName = listagemUsuarioController.ListagemDeUsuario(model, null);

        // Verificar se a página correta foi retornada
        Assertions.assertEquals("Usuario/ListagemDeUsuarios", viewName);

        // Verificar se os usuários foram adicionados ao modelo
        verify(model, times(1)).addAttribute(eq("usuarios"), eq(usuariosList));

        // Verificar se o repositório de usuários foi chamado corretamente
        verify(usuarioRepository, times(1)).findAll();

        // Exibir mensagem de sucesso no terminal
        System.out.println("Usuários listado com sucesso!");
    }

    @Test
    public void testAtivarUsuario() {
        MockitoAnnotations.openMocks(this);

        // Criar um usuário fictício
        Usuario usuario = new Usuario();
        usuario.setId(1L);

        // Configurar o comportamento do repositório de usuários
        when(usuarioRepository.findById(1L)).thenReturn(java.util.Optional.of(usuario));

        // Chamar o método de teste
        String viewName = listagemUsuarioController.AtivarUsuario(1L);

        // Verificar se a página de redirecionamento correta foi retornada
        Assertions.assertEquals("redirect:/Usuario/ListagemDeUsuarios", viewName);

        // Verificar se o usuário foi atualizado corretamente
        Assertions.assertEquals("ATIVO", usuario.getStatus());

        // Verificar se o repositório de usuários foi chamado corretamente
        verify(usuarioRepository, times(1)).findById(1L);
        verify(usuarioRepository, times(1)).save(usuario);

        // Exibir mensagem de sucesso no terminal
        System.out.println("Usuário ativado com sucesso!");
    }

    @Test
    public void testInativarUsuario() {
        MockitoAnnotations.openMocks(this);

        // Criar um usuário fictício
        Usuario usuario = new Usuario();
        usuario.setId(1L);

        // Configurar o comportamento do repositório de usuários
        when(usuarioRepository.findById(1L)).thenReturn(java.util.Optional.of(usuario));

        // Chamar o método de teste
        String viewName = listagemUsuarioController.InativarUsuario(1L);

        // Verificar se a página de redirecionamento correta foi retornada
        Assertions.assertEquals("redirect:/Usuario/ListagemDeUsuarios", viewName);

        // Verificar se o usuário foi atualizado corretamente
        Assertions.assertEquals("INATIVO", usuario.getStatus());

        // Verificar se o repositório de usuários foi chamado corretamente
        verify(usuarioRepository, times(1)).findById(1L);
        verify(usuarioRepository, times(1)).save(usuario);

        // Exibir mensagem de sucesso no terminal
        System.out.println("Usuário inativado com sucesso!");
    }

    @Test
    public void testEditarUsuario() {
        MockitoAnnotations.openMocks(this);
        // Criar um usuário fictício
        Usuario usuario = new Usuario();
        usuario.setId(1L);
        // Configurar o comportamento do repositório de usuários
        when(usuarioRepository.findById(1L)).thenReturn(java.util.Optional.of(usuario));
        // Criar um modelo fictício
        Model model = mock(Model.class);
        // Chamar o método de teste
        String viewName = listagemUsuarioController.EditarUsuario(1L, model);
        // Verificar se a página correta foi retornada
        Assertions.assertEquals("Usuario/FormularioEdicaoUsuario", viewName);
        // Verificar se o usuário foi adicionado ao modelo
        verify(model, times(1)).addAttribute(eq("usuario"), eq(usuario));

        // Verificar se o repositório de usuários foi chamado corretamente
        verify(usuarioRepository, times(1)).findById(1L);

        // Exibir mensagem de sucesso no terminal
        System.out.println("Usuário Editado com sucesso!");
    }

    @Test
    public void testListagemDeUsuario_CaixaPreta_Equivalencia() {
        MockitoAnnotations.openMocks(this);

        List<Usuario> usuariosList = Arrays.asList(
                createUsuario(1L, "João", "ATIVO"),
                createUsuario(2L, "Maria", "INATIVO"),
                createUsuario(3L, "Pedro", "ATIVO")
        );
        // Configurar o comportamento do repositório de usuários
        when(usuarioRepository.findAll()).thenReturn(usuariosList);
        // Criar um modelo fictício
        Model model = mock(Model.class);
        // Chamar o método de teste
        String viewName = listagemUsuarioController.ListagemDeUsuario(model, null);
        // Verificar se a página correta foi retornada
        Assertions.assertEquals("Usuario/ListagemDeUsuarios", viewName);
        // Verificar se os usuários foram adicionados ao modelo
        verify(model, times(1)).addAttribute(eq("usuarios"), eq(usuariosList));
        // Verificar se o repositório de usuários foi chamado corretamente
        verify(usuarioRepository, times(1)).findAll();
        // Exibir mensagem de sucesso no terminal
        System.out.println("Usuários listados com sucesso!");
    }
    private Usuario createUsuario(Long id, String nome, String status) {
        Usuario usuario = new Usuario();
        usuario.setId(id);
        usuario.setNome(nome);
        usuario.setStatus(status);
        return usuario;
    }

    @Test
    public void testEditarUsuario_UsuarioExistente() {
        MockitoAnnotations.openMocks(this);
        // Criar um usuário fictício para edição
        Usuario usuario = new Usuario();
        usuario.setId(1L);
        usuario.setNome("João");
        // Configurar o comportamento do repositório de usuários
        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuario));
        // Criar um modelo fictício
        Model model = mock(Model.class);
        // Chamar o método de teste
        String viewName = listagemUsuarioController.EditarUsuario(1L, model);
        // Verificar se a página correta foi retornada
        Assertions.assertEquals("Usuario/FormularioEdicaoUsuario", viewName);
        // Verificar se o usuário foi adicionado ao modelo
        verify(model, times(1)).addAttribute(eq("usuario"), eq(usuario));
        // Verificar se o repositório de usuários foi chamado corretamente
        verify(usuarioRepository, times(1)).findById(1L);
        // Exibir mensagem de sucesso no terminal
        System.out.println("Usuário editado com sucesso!");
    }

    @Test
    public void testEditarUsuario_UsuarioInexistente() {
        MockitoAnnotations.openMocks(this);
        // Configurar o comportamento do repositório de usuários para retornar um Optional vazio
        when(usuarioRepository.findById(1L)).thenReturn(Optional.empty());
        // Criar um modelo fictício
        Model model = mock(Model.class);
        // Chamar o método de teste
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            listagemUsuarioController.EditarUsuario(1L, model);
        });
        // Verificar se o modelo não contém o atributo de usuário
        verify(model, never()).addAttribute(eq("usuario"), any(Usuario.class));
        // Verificar se o repositório de usuários foi chamado corretamente
        verify(usuarioRepository, times(1)).findById(1L);
        // Exibir mensagem de sucesso no terminal
        System.out.println("Usuário inexistente!");
    }


}
