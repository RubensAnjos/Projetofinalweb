package br.com.ProjetoPI.FifaStore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FifaStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
